import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, Schema, Content } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Use provided GEMINI API KEY or fallback to environment
  const apiKey = process.env.GEMINI_API_KEY || "AQ.Ab8RN6JYyc4x0V7wPqmt0VfmDD4k1FYp9yXzzsdKF7-VPIHz2Q";
  const ai = new GoogleGenAI({ apiKey });

  // API routes
  app.post("/api/gemini", async (req, res) => {
    try {
      const { prompt, context, type } = req.body;
      
      let responseText = "";
      
      if (type === 'complex') {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: prompt,
          config: {
            thinkingConfig: {
              thinkingLevel: "HIGH"
            },
          }
        });
        responseText = response.text || "";
      } else if (type === 'search') {
        const response = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: prompt,
          config: {
            tools: [{ googleSearch: {} }]
          }
        });
        responseText = response.text;
      } else {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: prompt,
        });
        responseText = response.text;
      }
      
      res.json({ text: responseText });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
